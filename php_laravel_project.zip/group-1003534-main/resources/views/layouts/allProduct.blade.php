@extends('layouts.main')
@section('content')
    <section class="main-all-product">
      <article>
        
      </article>
    </section>
@endsection