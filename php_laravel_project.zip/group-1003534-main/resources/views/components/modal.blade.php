<div class="container-modal">
    <!-- Always remember that you are absolutely unique. Just like everyone else. - Margaret Mead -->
    <img src="{{ asset('images/modal_tea.png') }}" alt="">
    <h2>{{ $message }}</h2>
    <img src="{{ asset('images/modal_tea.png') }}" alt="">
</div>
